#!/usr/bin/env python3
"""Monta o pacote final do módulo EXT-ESP-SET-v1.1.

O empacotamento usa uma lista de inclusão fechada. Assim, camadas GEO brutas,
arquivos temporários e quaisquer outros dados existentes no diretório de
trabalho não são copiados por acidente.

Uso previsto (após a criação da planilha de síntese):

    python3 work/ext_espacial_setores_v1_1/build_package.py

Para uma montagem provisória, sem a planilha, use explicitamente:

    python3 work/ext_espacial_setores_v1_1/build_package.py \
        --allow-missing-workbook

O script cria, de forma determinística e idempotente:

* outputs/ext_espacial_s3_setorizacao_priorizacao_v1_1/
* outputs/ext_espacial_s3_setorizacao_priorizacao_v1_1.zip
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import zipfile


PACKAGE_ID = "ext_espacial_s3_setorizacao_priorizacao_v1_1"
WORKBOOK_NAME = "Sintese_Setorizacao_Priorizacao_DEV_S_v1_1.xlsx"

# Mapeamento explícito origem -> destino. Não substituir por glob recursivo.
REQUIRED_FILES: tuple[tuple[str, str], ...] = (
    ("README.md", "README.md"),
    (
        "ESPECIFICACAO_METODOLOGICA_SETOR_v1_1.md",
        "docs/ESPECIFICACAO_METODOLOGICA_SETOR_v1_1.md",
    ),
    (
        "config_setorizacao_priorizacao_v1_1.json",
        "config/config_setorizacao_priorizacao_v1_1.json",
    ),
    (
        "motor_setorizacao_priorizacao.py",
        "src/motor_setorizacao_priorizacao.py",
    ),
    (
        "test_motor_setorizacao_priorizacao.py",
        "qa/test_motor_setorizacao_priorizacao.py",
    ),
    (
        "verify_setorizacao_priorizacao.py",
        "qa/verify_setorizacao_priorizacao.py",
    ),
    ("build_package.py", "qa/build_package.py"),
    ("results/RESUMO_EXECUCAO_DEV_S.md", "results/RESUMO_EXECUCAO_DEV_S.md"),
    ("results/buffer_decisions_dev.csv", "results/buffer_decisions_dev.csv"),
    ("results/determinism_report.json", "results/determinism_report.json"),
    (
        "results/manifest_setorizacao_dev.json",
        "results/manifest_setorizacao_dev.json",
    ),
    ("results/sector_features_dev.csv", "results/sector_features_dev.csv"),
    (
        "results/sector_polygons_dev.geojson",
        "results/sector_polygons_dev.geojson",
    ),
    ("results/sector_ranking_dev.csv", "results/sector_ranking_dev.csv"),
    ("results/sector_results_dev.json", "results/sector_results_dev.json"),
    ("results/test_results.json", "results/test_results.json"),
    ("results/verification_report.json", "results/verification_report.json"),
    ("results/warnings_dev.log", "results/warnings_dev.log"),
)

WORKBOOK_FILE = (
    f"results/{WORKBOOK_NAME}",
    f"results/{WORKBOOK_NAME}",
)

PACKAGE_README = """# Pacote EXT-ESP-SET-v1.1 — DEV-S

Este pacote reúne o código, a configuração congelada, a especificação
metodológica, as verificações e os resultados da execução de setorização e
priorização espacial sobre os buffers do conjunto DEV-S.

## Estrutura

- `config/`: protocolo computacional congelado;
- `docs/`: especificação metodológica;
- `src/`: motor de processamento;
- `qa/`: testes e verificador independente;
- `results/`: resultados científicos e planilha de síntese para revisão.

## Limites de interpretação

Os resultados são diagnósticos e não confirmatórios. A prioridade calculada é
territorial e operacional; não representa probabilidade de presença da vítima.
O ground truth não foi utilizado no processamento ou na priorização.

## Dados não incluídos

As camadas GEO brutas e os insumos volumosos de processamento não são
duplicados neste pacote. As fontes, versões, caminhos e hashes necessários à
auditoria permanecem registrados no manifesto da execução e na configuração.
Uma reprodução integral exige acesso autorizado a esses insumos de origem.

Consulte `PACKAGE_MANIFEST.json` para a lista exata de arquivos, tamanhos e
hashes SHA-256 deste pacote.
"""


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--allow-missing-workbook",
        action="store_true",
        help=(
            "Permite pacote provisório sem a planilha de síntese. "
            "Por padrão, a planilha é obrigatória."
        ),
    )
    return parser.parse_args()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _assert_regular_file(path: Path, label: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Arquivo obrigatório ausente ({label}): {path}")
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"Arquivo inválido ou link simbólico ({label}): {path}")


def _copy_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def _inventory(package_root: Path) -> list[dict[str, object]]:
    files: list[dict[str, object]] = []
    for path in sorted(package_root.rglob("*")):
        if not path.is_file() or path.name == "PACKAGE_MANIFEST.json":
            continue
        files.append(
            {
                "path": path.relative_to(package_root).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": _sha256(path),
            }
        )
    return files


def _write_manifest(package_root: Path, workbook_included: bool) -> None:
    files = _inventory(package_root)
    manifest = {
        "package_id": PACKAGE_ID,
        "module_id": "EXT-ESP-SET-v1.1",
        "execution_stage": "DEV-S",
        "interpretation": "diagnostico_nao_confirmatorio",
        "ground_truth_used": False,
        "workbook_included": workbook_included,
        "raw_geo_layers_included": False,
        "file_count_excluding_manifest": len(files),
        "total_bytes_excluding_manifest": sum(int(item["bytes"]) for item in files),
        "files": files,
        "excluded_by_design": [
            "camadas GEO brutas",
            "caches e arquivos temporarios",
            "duplicata raiz test_results.json",
            "insumos upstream ja identificados por manifesto e hash",
        ],
    }
    destination = package_root / "PACKAGE_MANIFEST.json"
    destination.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _write_deterministic_zip(package_root: Path, zip_path: Path) -> None:
    """Cria ZIP byte-estável para conteúdo idêntico."""
    temp_zip = zip_path.with_suffix(".zip.tmp")
    if temp_zip.exists():
        temp_zip.unlink()

    with zipfile.ZipFile(
        temp_zip,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for source in sorted(path for path in package_root.rglob("*") if path.is_file()):
            relative = source.relative_to(package_root).as_posix()
            archive_name = f"{PACKAGE_ID}/{relative}"
            info = zipfile.ZipInfo(archive_name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, source.read_bytes(), compress_type=zipfile.ZIP_DEFLATED)

    os.replace(temp_zip, zip_path)


def main() -> int:
    args = _parse_args()
    module_root = Path(__file__).resolve().parent
    project_root = module_root.parents[1]
    output_root = (project_root / "outputs").resolve()
    package_root = (output_root / PACKAGE_ID).resolve()
    zip_path = (output_root / f"{PACKAGE_ID}.zip").resolve()

    expected_package_root = output_root / PACKAGE_ID
    if package_root != expected_package_root:
        raise RuntimeError(f"Destino recusado pela proteção de caminho: {package_root}")
    if package_root.is_symlink() or zip_path.is_symlink():
        raise RuntimeError("Destino do pacote ou ZIP não pode ser link simbólico.")

    selected_files = list(REQUIRED_FILES)
    workbook_source = module_root / WORKBOOK_FILE[0]
    if workbook_source.exists():
        _assert_regular_file(workbook_source, "planilha")
        selected_files.append(WORKBOOK_FILE)
        workbook_included = True
    elif args.allow_missing_workbook:
        workbook_included = False
    else:
        raise FileNotFoundError(
            "A planilha final ainda não existe: "
            f"{workbook_source}. Crie-a ou use --allow-missing-workbook "
            "somente para um pacote provisório."
        )

    for source_relative, _ in selected_files:
        _assert_regular_file(module_root / source_relative, source_relative)

    output_root.mkdir(parents=True, exist_ok=True)
    staging_root = Path(
        tempfile.mkdtemp(prefix=f".{PACKAGE_ID}.staging-", dir=output_root)
    )
    try:
        for source_relative, destination_relative in selected_files:
            _copy_file(
                module_root / source_relative,
                staging_root / destination_relative,
            )

        (staging_root / "PACOTE_LEIA_ME.md").write_text(
            PACKAGE_README,
            encoding="utf-8",
        )
        _write_manifest(staging_root, workbook_included)

        # A substituição atinge somente o destino fixo e previamente validado.
        previous_root = output_root / f".{PACKAGE_ID}.previous"
        if previous_root.exists():
            if previous_root.is_symlink():
                raise RuntimeError(f"Backup inesperado é link simbólico: {previous_root}")
            shutil.rmtree(previous_root)
        if package_root.exists():
            os.replace(package_root, previous_root)
        try:
            os.replace(staging_root, package_root)
        except Exception:
            if previous_root.exists() and not package_root.exists():
                os.replace(previous_root, package_root)
            raise
        if previous_root.exists():
            shutil.rmtree(previous_root)

        _write_deterministic_zip(package_root, zip_path)
    finally:
        if staging_root.exists():
            shutil.rmtree(staging_root)

    print(f"Pacote criado: {package_root}")
    print(f"ZIP criado: {zip_path}")
    print(f"Planilha incluída: {workbook_included}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
