# Pacote EXT-ESP-SET-v1.1 — DEV-S

Este pacote reúne o código, a configuração congelada, a especificação
metodológica, as verificações e os resultados da execução de setorização e
priorização espacial sobre os buffers do conjunto DEV-S.

## Estrutura

- `config/`: protocolo computacional congelado;
- `docs/`: especificação metodológica;
- `src/`: motor de processamento;
- `qa/`: testes e verificador independente;
- `results/`: resultados científicos e planilha de síntese para revisão.

## Limites de interpretação

Os resultados são diagnósticos e não confirmatórios. A prioridade calculada é
territorial e operacional; não representa probabilidade de presença da vítima.
O ground truth não foi utilizado no processamento ou na priorização.

## Dados não incluídos

As camadas GEO brutas e os insumos volumosos de processamento não são
duplicados neste pacote. As fontes, versões, caminhos e hashes necessários à
auditoria permanecem registrados no manifesto da execução e na configuração.
Uma reprodução integral exige acesso autorizado a esses insumos de origem.

Consulte `PACKAGE_MANIFEST.json` para a lista exata de arquivos, tamanhos e
hashes SHA-256 deste pacote.
